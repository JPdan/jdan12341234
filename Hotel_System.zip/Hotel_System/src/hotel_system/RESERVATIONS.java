
package hotel_system;

import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class RESERVATIONS {
    //alter TABLE reservation ADD CONSTRAINT fk_clients_id FOREIGN KEY (clients_id) REFERENCES clients(id) on DELETE CASCADE
    //alter TABLE reservation ADD CONSTRAINT fk_rooms_number FOREIGN KEY (rooms_number) REFERENCES rooms(r_number) on DELETE CASCADE
    //alter TABLE rooms ADD CONSTRAINT fk_type_id FOREIGN KEY (type) REFERENCES type(id) on DELETE CASCADE
    
    MY_CONNECTION my_connection = new MY_CONNECTION();
    
    ROOMS room = new ROOMS();
    
    public boolean addReservation(int clients_id, int rooms_number, String check_in, String check_out) throws SQLException
{
    
    PreparedStatement st;
    String addQuery = "INSERT INTO `reservation`(`clients_id`, `rooms_number`, `check_in`, `check_out`) VALUES (?,?,?,?)";
    
    // Check if clients_id exists in clients table
    boolean clientExists = false;
    PreparedStatement checkClientStmt = my_connection.createConnection().prepareStatement("SELECT COUNT(*) FROM clients WHERE id = ?");
    checkClientStmt.setInt(1, clients_id);
    ResultSet checkClientResultSet = checkClientStmt.executeQuery();
    if (checkClientResultSet.next()) {
        int count = checkClientResultSet.getInt(1);
        if (count > 0) {
            clientExists = true;
        }
    }
    if (!clientExists) {
        return false;
    }
    
    try {
        
        st = my_connection.createConnection().prepareStatement(addQuery);
        
        st.setInt(1, clients_id);
        st.setInt(2, rooms_number);
        st.setString(3, check_in);
        st.setString(4, check_out);
        
        if (st.executeUpdate()>0)
        {
            room.setRoomToReserve(rooms_number, "Yes");
            return true;
        } else {
                
                
                
            return false;
        }
        
    } catch (SQLException ex) {
        Logger.getLogger(CLIENTS.class.getName()).log(Level.SEVERE, null, ex);
        
        return false;
    }
}
    
    public boolean editReservation(int reservation_id, int clients_id, int rooms_number, String check_in, String check_out) {
        PreparedStatement st;
        String editQuery = "UPDATE `reservation` SET `clients_id`=?,`rooms_number`=?,`check_in`=?,`check_out`=? WHERE `id`=?";
    
        try {
            st = my_connection.createConnection().prepareStatement(editQuery);
        
            st.setInt(1, reservation_id);
            st.setInt(2, clients_id);
            st.setInt(3, rooms_number);
            st.setString(4, check_in);
            st.setString(5, check_out);
  
            return (st.executeUpdate() > 0);
        } catch (SQLException ex) {
            Logger.getLogger(CLIENTS.class.getName()).log(Level.SEVERE, null, ex);
        
            return false;
        }
    }

    public boolean removeReservation(int reservation_id) {
    PreparedStatement st;
    String deleteQuery = "DELETE FROM `reservation` WHERE `id`=?";

    try {
        st = my_connection.createConnection().prepareStatement(deleteQuery);

        st.setInt(1, reservation_id);

        int rooms_number = getRoomNumberFromReservation(reservation_id);
        if (st.executeUpdate() > 0) {
            room.setRoomToReservation(rooms_number, "No");
            return true;
        } else {
            return false;
        }
    } catch (SQLException ex) {
        Logger.getLogger(CLIENTS.class.getName()).log(Level.SEVERE, null, ex);
        return false;
    }
}
    
    public void fillReservationJtable(JTable table)
    {
    PreparedStatement ps;
         ResultSet rs;
         String selectQuery = "SELECT * FROM `reservation`";
     
         
        try {
            ps = my_connection.createConnection().prepareStatement(selectQuery);
            
            rs = ps.executeQuery();
            
            DefaultTableModel tableModel = (DefaultTableModel)table.getModel();
            
            Object[] row;
            
            while(rs.next())
            {
                row = new Object[5];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getString(5);
                
              tableModel.addRow(row);
     
        }
            
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(CLIENTS.class.getName()).log(Level.SEVERE, null, ex);
        }
     
     
     }
     public int getRoomNumberFromReservation(int reservationID){
         PreparedStatement ps;
         ResultSet rs;
         String selectQuery = "SELECT `rooms_number`FROM `reservation` WHERE `id`=?";
     
         
        try {
            ps = my_connection.createConnection().prepareStatement(selectQuery);
            
            rs = ps.executeQuery();
            
            if(rs.next())
            {
                return rs.getInt(1);
            }else{
                return 0;
            }

        }
        catch (SQLException ex) {
            
            Logger.getLogger(CLIENTS.class.getName()).log(Level.SEVERE, null, ex);
             return 0;
        }
    }
     
}
